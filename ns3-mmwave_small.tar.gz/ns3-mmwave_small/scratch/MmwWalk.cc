#include "ns3/epc-helper.h"
#include "ns3/ipv4-global-routing-helper.h"
#include "ns3/internet-module.h"
#include "ns3/applications-module.h"
#include "ns3/point-to-point-helper.h"
#include "ns3/mmwave-point-to-point-epc-helper.h"
#include "ns3/mmwave-propagation-loss-model.h"
#include "ns3/network-module.h"
#include "mmwScenariosUtils.h"
#include "mmwScenariosTraces.h"
#include <time.h>
using namespace ns3;

class MyApp : public Application
{
public:
  MyApp();
  virtual ~MyApp();

  void Setup(Ptr<Socket> socket, Address address, uint32_t packetSize, DataRate dataRate, uint64_t npackets = 0);

private:
  virtual void StartApplication(void);
  virtual void StopApplication(void);

  void ScheduleTx(void);
  void SendPacket(void);

  Ptr<Socket> m_socket;
  Address m_peer;
  uint32_t m_packetSize;
  uint64_t m_nPackets;
  DataRate m_dataRate;
  EventId m_sendEvent;
  bool m_running;
  uint64_t m_sentPackets;
};

MyApp::MyApp()
    : m_socket(0),
      m_peer(),
      m_packetSize(0),
      m_nPackets(0),
      m_dataRate(0),
      m_sendEvent(),
      m_running(false),
      m_sentPackets(0)
{
}

MyApp::~MyApp()
{
  m_socket = 0;
}

void MyApp::Setup(Ptr<Socket> socket, Address address, uint32_t packetSize, DataRate dataRate, uint64_t npackets)
{
  m_socket = socket;
  m_peer = address;
  m_packetSize = packetSize;
  m_dataRate = dataRate;
  m_nPackets = npackets;
}

void MyApp::StartApplication(void)
{
  m_running = true;
  m_socket->Bind();
  m_socket->Connect(m_peer);
  if (m_nPackets == 0 || m_sentPackets < m_nPackets)
  {
    std::cout << "sent " << m_sentPackets << " / " << m_nPackets << std::endl;
    ++m_sentPackets;
    SendPacket();
  }
}

void MyApp::StopApplication(void)
{
  m_running = false;

  if (m_sendEvent.IsRunning())
  {
    Simulator::Cancel(m_sendEvent);
  }

  if (m_socket)
  {
    m_socket->Close();
  }
}

void MyApp::SendPacket(void)
{

  uint8_t *buffer = new uint8_t[m_packetSize];
  memcpy(buffer, &m_sentPackets, sizeof(m_sentPackets));
  Ptr<Packet> packet = Create<Packet>(buffer, m_packetSize);
  delete buffer;

  m_socket->Send(packet);
  AppTx(packet);
  ScheduleTx();
}

void MyApp::ScheduleTx(void)
{
  if (m_running && (m_nPackets == 0 || m_sentPackets < m_nPackets))
  {
    Time tNext(Seconds(m_packetSize * 8 / static_cast<double>(m_dataRate.GetBitRate())));
    m_sendEvent = Simulator::Schedule(tNext, &MyApp::SendPacket, this);
    ++m_sentPackets;
  }
}

static auto minDist = 0;

NS_LOG_COMPONENT_DEFINE("MmwAlone");

static void
updateLoS(Ptr<MmWave3gppPropagationLossModel> model, std::string cs)
{

  model->SetChannelStates(cs);
  std::cout << Simulator::Now().GetSeconds() << " -- Updating LoS" << std::endl;
  // Simulator::Schedule(MilliSeconds(100), &updateLoS, model, (cs == "l" ? "n" : "l"));
}

static void
fixLoss(Ptr<MmWave3gppPropagationLossModel> model, double loss)
{

  model->SetLossFixedDb(loss);
  std::cout << Simulator::Now().GetSeconds() << " --Losses fixed to " << loss << std::endl;
  // Simulator::Schedule(MilliSeconds(100), &updateLoS, model, (cs == "l" ? "n" : "l"));
}

int main(int argc, char *argv[])
{

  // LogComponentEnable("MmWaveEnbMac", LOG_LEVEL_DEBUG);
  int dist = std::stoi(argv[1]);
  std::string bw = argv[2];
  auto simTime = std::stoi(argv[3]);

  std::cout << "Distance " << dist << " m and BW " << bw << std::endl;
  auto init = 500;

  SetDefaultConfig();
  {
    std::stringstream ss;
    ss << "RxPhy_" << bw << "_" << std::setw(4) << std::setfill('0') << dist << ".txt";
    Config::SetDefault("ns3::MmWavePhyRxTrace::OutputFilename", StringValue(ss.str()));
  }
  // srand(time(0));
  auto rr = rand();
  std::cout << rr << std::endl;
  RngSeedManager::SetRun(rr);
  // RngSeedManager::SetRun(rand());
  auto mmwaveHelper = CreateObject<MmWaveHelper>();

  // settings for channel
  Set3gppChannel(mmwaveHelper, "UMa");

  auto epcHelper = CreateObject<MmWavePointToPointEpcHelper>();
  mmwaveHelper->SetEpcHelper(epcHelper);
  mmwaveHelper->SetHarqEnabled(false);
  auto pgw = epcHelper->GetPgwNode();

  NodeContainer remoteHostContainer;
  remoteHostContainer.Create(1);
  auto remoteHost = remoteHostContainer.Get(0);

  NodeContainer ueNodes;
  NodeContainer enbNodes;
  enbNodes.Create(1);
  ueNodes.Create(1);

  // Install Mobility Model
  auto enbPositionAlloc = CreateObject<ListPositionAllocator>();
  enbPositionAlloc->Add(Vector(minDist, 0.0, 10.0));
  MobilityHelper enbmobility;
  enbmobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
  enbmobility.SetPositionAllocator(enbPositionAlloc);
  enbmobility.Install(enbNodes);
  auto model = enbNodes.Get(0)->GetObject<MobilityModel>();

  // SetConstantVelocity(ueNodes, Vector(10, 0, hUT), Vector(50, 0, 0));
  SetConstantPosition(ueNodes, Vector(dist, 0, hUT));
  // SetRandomWalkMobilityModel(ueNodes);
  // Simulator::Schedule(Seconds(1), &UpdateInfo, ueNodes.Get(0), posTx.str());
  // Simulator::Schedule(Seconds(1), &UpdateInfo, ueNodes.Get(0));
  // Config::Connect("/NodeList/*/$ns3::MobilityModel/CourseChange", MakeCallback(&CourseChange));

  // Install mmWave Devices to the nodes
  NetDeviceContainer enbmmWaveDevs = mmwaveHelper->InstallEnbDevice(enbNodes);
  NetDeviceContainer uemmWaveDevs = mmwaveHelper->InstallUeDevice(ueNodes);

  // Install IP stack and create Internet
  InternetStackHelper internet;
  internet.Install(remoteHostContainer);
  PointToPointHelper p2ph;
  p2ph.SetDeviceAttribute("DataRate", DataRateValue(DataRate("100Gb/s")));
  p2ph.SetDeviceAttribute("Mtu", UintegerValue(1500));
  p2ph.SetChannelAttribute("Delay", TimeValue(MicroSeconds(100.0)));
  auto internetDevices = p2ph.Install(pgw, remoteHost);
  Ipv4AddressHelper ipv4h;
  ipv4h.SetBase("1.0.0.0", "255.0.0.0");
  auto internetIpIfaces = ipv4h.Assign(internetDevices);
  Ipv4StaticRoutingHelper ipv4RoutingHelper;
  auto remoteHostStaticRouting = ipv4RoutingHelper.GetStaticRouting(remoteHost->GetObject<Ipv4>());
  remoteHostStaticRouting->AddNetworkRouteTo(Ipv4Address("7.0.0.0"), Ipv4Mask("255.0.0.0"), 1);
  internet.Install(ueNodes);
  auto ueIpIface = epcHelper->AssignUeIpv4Address(uemmWaveDevs);
  // std::cout << "PGW address " << internetIpIfaces.GetAddress(0) << std::endl;
  // std::cout << "Remote host address " << internetIpIfaces.GetAddress(1) << std::endl;
  // std::cout << "UE address " << ueIpIface.GetAddress(0) << std::endl;

  auto ueNode = ueNodes.Get(0);
  auto ueStaticRouting = ipv4RoutingHelper.GetStaticRouting(ueNode->GetObject<Ipv4>());
  ueStaticRouting->SetDefaultRoute(epcHelper->GetUeDefaultGatewayAddress(), 1);
  mmwaveHelper->AttachToClosestEnb(uemmWaveDevs, enbmmWaveDevs);

  ApplicationContainer clientApps;
  ApplicationContainer serverApps;
  // Install and start applications on UEs and remote host
  auto dlPort = 1234u;
  auto dataRate = bw;
  Address sinkAddress(InetSocketAddress(ueIpIface.GetAddress(0), dlPort));
  // OnOffHelper onoff("ns3::UdpSocketFactory", sinkAddress);
  // onoff.SetAttribute("PacketSize", UintegerValue(packetSize));
  // onoff.SetAttribute("DataRate", StringValue(dataRate));
  // // onoff.SetAttribute("MaxBytes", UintegerValue(packetSize * 3)); // if not set it never ends
  // onoff.SetAttribute("OnTime", StringValue("ns3::ConstantRandomVariable[Constant=1000]"));
  // onoff.SetAttribute("OffTime", StringValue("ns3::ConstantRandomVariable[Constant=0]"));
  // serverApps.Add(onoff.Install(remoteHost));
  Ptr<Socket> ns3Socket = Socket::CreateSocket(remoteHostContainer.Get(0), UdpSocketFactory::GetTypeId());
  Ptr<MyApp> app = CreateObject<MyApp>();
  app->Setup(ns3Socket, sinkAddress, 1472, DataRate(bw));
  remoteHostContainer.Get(0)->AddApplication(app);
  // serverApps.Add(AddApplication(app);
  // serverApps.Get(0)->TraceConnectWithoutContext("Tx", MakeCallback(&AppTx));

  PacketSinkHelper sink("ns3::UdpSocketFactory", InetSocketAddress(Ipv4Address::GetAny(), dlPort));
  clientApps.Add(sink.Install(ueNodes.Get(0)));
  clientApps.Get(clientApps.GetN() - 1)->TraceConnectWithoutContext("Rx", MakeCallback(&AppRx));

  app->SetStartTime(MilliSeconds(init));
  // serverApps.Start(MilliSeconds(init));
  clientApps.Start(MilliSeconds(init));
  clientApps.Stop(MilliSeconds(simTime));
  Simulator::Stop(MilliSeconds(simTime));
  mmwaveHelper->EnableDlPhyTrace();

  auto lossModel = mmwaveHelper->GetPathLossModel(0)->GetObject<MmWave3gppPropagationLossModel>();
  // Simulator::Schedule(MilliSeconds(1), &updateLoS, lossModel, "l");

  // Simulator::Schedule(MilliSeconds(5000), &updateLoS, lossModel, "n");
  // Simulator::Schedule(MilliSeconds(10000), &updateLoS, lossModel, "l");
  // Simulator::Schedule(MilliSeconds(15000), &updateLoS, lossModel, "n");
  // Simulator::Schedule(MilliSeconds(20000), &updateLoS, lossModel, "l");

  // Simulator::Schedule(MilliSeconds(15000), &updateLoS, lossModel, "n");
  // Simulator::Schedule(MilliSeconds(20000), &updateLoS, lossModel, "l");

  // Simulator::Schedule(MilliSeconds(400), &fixLoss, lossModel, 10000.0);

  Simulator::Run();
  Simulator::Destroy();
  {
    Ptr<PacketSink> sink = StaticCast<PacketSink>(clientApps.Get(0));
    auto totalRx = sink->GetTotalRx();
    std::cout << "Reception thput = " << float(totalRx * 8 / (simTime - init)) * 1e-3 << " Mbps" << std::endl;
  }

  PrintRegularTrace(dist, init, bw);
  // {
  //   std::stringstream ss;
  //   ss << "_" << bw << "_" << std::setw(4) << std::setfill('0') << dist << ".txt";
  //   MySingleton::GetInstance().PrintTimeEvol(ss.str());
  // }
  return 0;
}