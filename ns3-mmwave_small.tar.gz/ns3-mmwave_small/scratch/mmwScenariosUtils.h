#ifndef MMWSCENARIOSUTILS_H
#define MMWSCENARIOSUTILS_H

#include "ns3/core-module.h"
#include "ns3/rng-seed-manager.h"
#include "ns3/config-store.h"
#include "ns3/mmwave-helper.h"
#include "ns3/mobility-module.h"

using namespace ns3;
using namespace mmwave;

static auto hUT = 1.5;
static auto bufferSize = 1024;

static void
SetDefaultConfig()
{
  Config::SetDefault("ns3::MmWaveHelper::RlcAmEnabled", BooleanValue(true));
  Config::SetDefault("ns3::MmWaveHelper::HarqEnabled", BooleanValue(true));
  // Config::SetDefault("ns3::MmWaveAmc::AmcModel", EnumValue(MmWaveAmc::PiroEW2010));
  // Config::SetDefault("ns3::MmWaveAmc::Ber", DoubleValue(0.01));
  // Config::SetDefault("ns3::MmWaveHelper::Scheduler", StringValue("ns3::MmWaveFlexTtiMaxRateMacScheduler"));
  // Config::SetDefault("ns3::MmWaveHelper::Scheduler", StringValue("ns3::MmWaveFlexTtiMaxWeightMacScheduler"));

  // Config::SetDefault("ns3::MmWaveFlexTtiMacScheduler::HarqEnabled", BooleanValue(false));
  // Config::SetDefault("ns3::MmWaveFlexTtiMaxWeightMacScheduler::HarqEnabled", BooleanValue(false));
  // Config::SetDefault("ns3::MmWaveFlexTtiMaxWeightMacScheduler::FixedTti", BooleanValue(true));
  // Config::SetDefault("ns3::MmWaveFlexTtiMacScheduler::FixedTti", BooleanValue(false));

  //    Config::SetDefault("ns3::MmWaveFlexTtiMaxWeightMacScheduler::SymPerSlot", UintegerValue(6));
  //    Config::SetDefault("ns3::MmWavePhyMacCommon::ResourceBlockNum", UintegerValue(1));
  //    Config::SetDefault("ns3::MmWavePhyMacCommon::ChunkPerRB", UintegerValue(72));
  //    Config::SetDefault("ns3::MmWavePhyMacCommon::SymbolsPerSubframe", UintegerValue(symPerSf));
  //    Config::SetDefault("ns3::MmWavePhyMacCommon::SubframePeriod", DoubleValue(sfPeriod));
  //    Config::SetDefault("ns3::MmWavePhyMacCommon::TbDecodeLatency", UintegerValue(200.0));
  //    Config::SetDefault("ns3::MmWavePhyMacCommon::NumHarqProcess", UintegerValue(100));
  //    Config::SetDefault("ns3::MmWaveBeamforming::LongTermUpdatePeriod", TimeValue(MilliSeconds(100.0)));
  //    Config::SetDefault("ns3::LteEnbRrc::SystemInformationPeriodicity", TimeValue(MilliSeconds(1.0)));
  //    Config::SetDefault("ns3::LteRlcAm::ReportBufferStatusTimer", TimeValue(MilliSeconds(1.0)));
  //    Config::SetDefault("ns3::LteRlcUmLowLat::ReportBufferStatusTimer", TimeValue(MicroSeconds(100.0)));
  //    Config::SetDefault("ns3::LteEnbRrc::SrsPeriodicity", UintegerValue(320));
  //    Config::SetDeafult("ns3::LteEnbRrc::FirstSibTime", UintegerValue(2));
  Config::SetDefault("ns3::LteRlcUm::MaxTxBufferSize", UintegerValue(bufferSize * 1024 * 1024));
  Config::SetDefault("ns3::LteRlcUmLowLat::MaxTxBufferSize", UintegerValue(bufferSize * 1024 * 1024));
  //    Config::SetDefault("ns3::LteRlcAm::StatusProhibitTimer", TimeValue(MilliSeconds(10.0)));
  //    Config::SetDefault("ns3::LteRlcAm::MaxTxBufferSize", UintegerValue(bufferSize * 1024 * 1024));
  //    Config::SetDefault("ns3::LteEnbRrc::FixedTttValue", UintegerValue(150));
  //    Config::SetDefault("ns3::LteEnbRrc::CrtPeriod", IntegerValue(ReportTablePeriodicity));
  //    Config::SetDefault("ns3::LteEnbRrc::OutageThreshold", DoubleValue(outageTh));
  //    Config::SetDefault("ns3::MmWaveEnbPhy::UpdateSinrEstimatePeriod", IntegerValue(ReportTablePeriodicity));
  //    Config::SetDefault("ns3::MmWaveEnbPhy::Transient", IntegerValue(vectorTransient));
  //    Config::SetDefault("ns3::MmWaveEnbPhy::NoiseAndFilter", BooleanValue(noiseAndFilter));

  Config::SetDefault("ns3::MmWave3gppPropagationLossModel::ChannelCondition", StringValue("a"));
  Config::SetDefault("ns3::MmWave3gppPropagationLossModel::Scenario", StringValue("UMa"));
  // Config::SetDefault("ns3::MmWave3gppPropagationLossModel::OptionalNlos", BooleanValue(true));
  Config::SetDefault("ns3::MmWave3gppPropagationLossModel::Shadowing", BooleanValue(true));                // enable or disable the shadowing effect
  Config::SetDefault("ns3::MmWave3gppBuildingsPropagationLossModel::UpdateCondition", BooleanValue(true)); // enable or disable the LOS/NLOS update when the UE moves
                                                                                                           //    Config::SetDefault("ns3::AntennaArrayModel::AntennaHorizontalSpacing", DoubleValue(0.5));
                                                                                                           //    Config::SetDefault("ns3::AntennaArrayModel::AntennaVerticalSpacing", DoubleValue(0.5));
  Config::SetDefault("ns3::MmWave3gppChannel::UpdatePeriod", TimeValue(MilliSeconds(1)));                  // interval after which the channel for a moving user is updated,
  // with spatial consistency procedure. If 0, spatial consistency is not used
  Config::SetDefault("ns3::MmWave3gppChannel::DirectBeam", BooleanValue(true));      // Set true to perform the beam in the exact direction of receiver node.
  Config::SetDefault("ns3::MmWave3gppChannel::Blockage", BooleanValue(true));        // use blockage or not
  Config::SetDefault("ns3::MmWave3gppChannel::PortraitMode", BooleanValue(true));    // use blockage model with UT in portrait mode
  Config::SetDefault("ns3::MmWave3gppChannel::NumNonselfBlocking", IntegerValue(4)); // number of non-self blocking obstacles
  // set the number of antennas in the devices
  Config::SetDefault("ns3::McUeNetDevice::AntennaNum", UintegerValue(1));      // 16
  Config::SetDefault("ns3::MmWaveEnbNetDevice::AntennaNum", UintegerValue(1)); // 64
}

static void
Set3gppChannel(Ptr<MmWaveHelper> mmwaveHelper, std::string scenario)
{
  Config::SetDefault("ns3::MmWave3gppPropagationLossModel::Scenario", StringValue(scenario));
  mmwaveHelper->SetAttribute("PathlossModel", StringValue("ns3::MmWave3gppPropagationLossModel"));
  mmwaveHelper->SetAttribute("ChannelModel", StringValue("ns3::MmWave3gppChannel"));
}

// static void
// SetRandomWalkMobilityModel(NodeContainer &ueNodes)
// {
//   MobilityHelper uemobility;
//   uemobility.SetMobilityModel("ns3::RandomWalk2dMobilityModel",
//                               "Mode", StringValue("Time"),
//                               "Time", StringValue("1ms"),
//                               "Speed", StringValue("ns3::ConstantRandomVariable[Constant=20.0]"),
//                               "Bounds", StringValue("-500|500|-500|500"));
//   uemobility.SetPositionAllocator("ns3::RandomDiscPositionAllocator",
//                                   "X", StringValue("10.0"),
//                                   "Y", StringValue("10.0"),
//                                   "Z", StringValue("1.5"),
//                                   "Rho", StringValue("ns3::UniformRandomVariable[Min=0|Max=10]"));
//   uemobility.Install(ueNodes);
// }

// static void
// SetConstantVelocity(NodeContainer &nodes, Vector init, Vector vel)
// {
//   MobilityHelper mobility;
//   mobility.SetMobilityModel("ns3::ConstantVelocityMobilityModel");
//   auto posAlloc = CreateObject<ListPositionAllocator>();
//   posAlloc->Add(init);
//   mobility.SetPositionAllocator(posAlloc);
//   mobility.Install(nodes);
//   auto model = nodes.Get(0)->GetObject<ConstantVelocityMobilityModel>();
//   model->SetVelocity(vel);
// }

static void
SetConstantPosition(NodeContainer &nodes, Vector pos)
{
  MobilityHelper mobility;
  auto posAlloc = CreateObject<ListPositionAllocator>();
  posAlloc->Add(pos);
  mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
  mobility.SetPositionAllocator(posAlloc);
  mobility.Install(nodes);
}

#endif /* MMWSCENARIOSUTILS_H */
