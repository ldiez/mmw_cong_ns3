#ifndef MMWSCENARIOSTRACES_H
#define MMWSCENARIOSTRACES_H

#include "ns3/core-module.h"
#include "ns3/mobility-module.h"
#include "ns3/CongTag.h"
#include "ns3/MySingleton.h"
#include <fstream>
#include <map>
#include <sstream>
#include <string>
#include <iomanip>

using namespace ns3;

struct PacketLog
{
  ns3::Time m_txTime = Seconds(0.0);
  ns3::Time m_rxTime = Seconds(0.0);
  ns3::Time m_iat = Seconds(0.0);
  double m_buffOccRx = 0.0;
  double m_buffOccTx = 0.0;
};

// for normal traces
static std::map<uint64_t, PacketLog> s_paketLog;

static uint64_t s_txCtr = 0;
static uint64_t s_rxCtr = 0;
static Time s_lastRx = Seconds(0.5);

static uint64_t
GetSn(Ptr<const Packet> pkt)
{
  uint8_t *buffer = new uint8_t[pkt->GetSize()];
  auto copied = pkt->CopyData(buffer, pkt->GetSize());
  uint64_t sn;
  memcpy(&sn, buffer, sizeof(sn));
  delete buffer;
  return sn;
}

static void AppTx(Ptr<const Packet> pkt)
{
  auto sn = GetSn(pkt);
  ++s_txCtr;
  auto now = Simulator::Now();
  PacketLog pl;
  pl.m_txTime = now;
  // pl.m_buffOccTx = ((s_txCtr - s_rxCtr)) * pkt->GetSize();
  s_paketLog.insert({sn, pl});

  if (s_txCtr % 1000 == 0)
  {
    std::cout << "++ @ " << now.GetSeconds() << std::endl;
  }
}

static void
AppRx(Ptr<const Packet> pkt, const Address &)
{
  auto sn = GetSn(pkt);
  ++s_rxCtr;
  auto now = Simulator::Now();
  s_paketLog.at(sn).m_rxTime = now;
  // s_paketLog.at(sn).m_buffOccRx = ((s_txCtr - s_rxCtr)) * pkt->GetSize();
  s_paketLog.at(sn).m_iat = (now - s_lastRx);
  s_lastRx = now;

  if (s_rxCtr % 1000 == 0)
  {
    std::cout << "-- @ " << now.GetSeconds() << std::endl;
  }
}

static void
PrintRegularTrace(int dist, uint64_t init, std::string bw)
{ //trace files
  std::cout << "Received " << s_rxCtr << "/" << s_txCtr << " >> " << s_rxCtr * 1472 << "/" << s_txCtr * 1472 << " bytes " << std ::endl;
  std::stringstream appRx;
  appRx << "traces/static_" << bw << "_" << std::setw(4) << std::setfill('0') << dist << ".txt";
  // appRx << "./proof_" << bw << "_" << std::setw(4) << std::setfill('0') << dist << ".txt";
  std::ofstream appRxOfs;
  appRxOfs.open(appRx.str());
  // appRxOfs << "seq,txTime,occTx,rxTime,occRx,delay,iat" << std::endl;
  auto ctr = 1;
  auto uAcked = 0u;
  auto buffer = MySingleton::GetInstance().GetActualBufferEvol();
  for (auto item : s_paketLog)
  {
    auto occIt = buffer.lower_bound(item.second.m_rxTime);
    auto occ = 0.0;
    if (occIt != buffer.begin())
    {
      occ = ((--occIt)->second);
    }
    if (item.second.m_rxTime == 0)
    {
      ++uAcked;
      continue;
      // appRxOfs << ctr
      //          << ", " << item.second.m_txTime.GetSeconds()
      //          << ", " << item.second.m_buffOccTx
      //          << ", " << -1
      //          << ", " << -1
      //          << ", " << -1
      //          << ", " << -1
      //          << std::endl;
    }
    else
    {
      appRxOfs << ctr
               << ", " << item.second.m_rxTime.GetSeconds()
               << ", " << occ
               << ", " << (item.second.m_rxTime.GetSeconds() - item.second.m_txTime.GetSeconds()) * 1000
               << ", " << (item.second.m_iat.GetSeconds()) * 1000
               << std::endl;
    }
    ++ctr;
  }
  std::cout << "++++++++++++++++-------------- unACK " << uAcked << std::endl;
  appRxOfs.close();
}

#endif /* MMWSCENARIOSTRACES_H */