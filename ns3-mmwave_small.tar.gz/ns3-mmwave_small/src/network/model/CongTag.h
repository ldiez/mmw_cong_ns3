#ifndef CONG_TAG_H
#define CONG_TAG_H

#include "ns3/tag.h"
#include "ns3/packet.h"

namespace ns3
{
class CongTag : public Tag
{
public:
  static TypeId GetTypeId(void);
  virtual TypeId GetInstanceTypeId(void) const;
  virtual uint32_t GetSerializedSize(void) const;
  virtual void Serialize(TagBuffer i) const;
  virtual void Deserialize(TagBuffer i);
  virtual void Print(std::ostream &os) const;

  void SetPktCtr(uint64_t value);
  uint64_t GetPktCtr(void) const;

private:
  uint64_t m_pktCtr; //!< tag value
};

} // namespace ns3
#endif