#include "CongTag.h"
#include "ns3/uinteger.h"
namespace ns3
{
TypeId
CongTag::GetTypeId(void)
{
  static TypeId tid = TypeId("ns3::CongTag")
                          .SetParent<Tag>()
                          .AddConstructor<CongTag>()
      // .AddAttribute("Counter", "The application packet counter",
      //               EmptyAttributeValue(),
      //               MakeUintegerAccessor(&CongTag::GetPktCtr),
      //               MakeUintegerChecker<uint32_t>())
      ;
  return tid;
}
TypeId
CongTag::GetInstanceTypeId(void) const
{
  return GetTypeId();
}

uint32_t CongTag::GetSerializedSize(void) const
{
  return sizeof(m_pktCtr);
}

void CongTag::Serialize(TagBuffer i) const
{
  i.WriteU64(m_pktCtr);
  // i.Write((uint8_t *)(&m_pktCtr), sizeof(m_pktCtr));
}

void CongTag::Deserialize(TagBuffer i)
{
  // i.Read((uint8_t *)(&m_pktCtr), sizeof(m_pktCtr));
  m_pktCtr = i.ReadU64();
}

void CongTag::Print(std::ostream &os) const
{
  os << "v=" << m_pktCtr;
}

void CongTag::SetPktCtr(uint64_t value)
{
  m_pktCtr = value;
}

uint64_t CongTag::GetPktCtr(void) const
{
  return m_pktCtr;
}
} // namespace ns3