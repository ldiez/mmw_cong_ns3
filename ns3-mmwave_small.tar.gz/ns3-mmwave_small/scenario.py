import os
import itertools
import pandas as pd

bws = ["10Mbps", "20Mbps", "30Mbps", "40Mbps", "50Mbps",
       "100Mbps", "200Mbps", "500Mbps", "1000Mbps"]
dists = [10, 20, 30, 40, 50]  # meters
# bws = ["10Mbps"]
# dists = [30]  # meters
times = [600000]  # ms
for (bw, dist, time) in itertools.product(bws, dists, times):
    cmd = './waf --run "MmwWalk {} {} {}"'.format(dist, bw, time)
    # print(cmd)
    os.system(cmd)
    fn = './traces/DlRxPhy_{}_{:04d}.txt'.format(bw, dist)
    print(fn)
    data = pd.read_csv(fn, sep='\t', usecols=[
                       'time', 'tbSize', 'mcs', 'SINR(dB)'])
    data.to_csv(fn, index=False, header=False)
